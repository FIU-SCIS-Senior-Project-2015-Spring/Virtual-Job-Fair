var gplus_me = require('../google_plus/me');

module.exports = gplus_me;