//
//Copyright (c) 2013, Priologic Software Inc.
//All rights reserved.
//
//Redistribution and use in source and binary forms, with or without
//modification, are permitted provided that the following conditions are met:
//
//    * Redistributions of source code must retain the above copyright notice,
//      this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above copyright
//      notice, this list of conditions and the following disclaimer in the
//      documentation and/or other materials provided with the distribution.
//
//THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//POSSIBILITY OF SUCH DAMAGE.
//
var selfEasyrtcid = "";

function disable(id) {
    document.getElementById(id).disabled = "disabled";
}


function enable(id) {
    document.getElementById(id).disabled = "";
}


function connect() {
    console.log("Initializing.");
    easyRTC.enableAudio(document.getElementById('shareAudio').checked);
    easyRTC.enableVideo(document.getElementById('shareVideo').checked);
    easyRTC.setLoggedInListener(convertListToButtons);
    easyRTC.initMediaSource(
        function(){        // success callback
            var selfVideo = document.getElementById("selfVideo");
            easyRTC.setVideoObjectSrc(selfVideo, easyRTC.getLocalStream());
            easyRTC.connect(sessionID, loginSuccess, loginFailure);
        },
        function(errmesg){
            alert(errmesg);
        }  // failure callback
        );
            
            
    easyRTC.setDataListener(addToConversation);
}

function addToConversation(who, content) {
    if(who != "ME"){
    // Escape html special characters, then add linefeeds.
    content = content.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    content = content.replace(/\n/g, '<br />');
    document.getElementById('conversation').innerHTML += 
    "<b>" + view_value + ":</b>&nbsp;" + content + "<br />";
}
else   if(who == "ME"){
        // Escape html special characters, then add linefeeds.
    content = content.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    content = content.replace(/\n/g, '<br />');
    document.getElementById('conversation').innerHTML += 
    "<b>" + who + ":</b>&nbsp;" + content + "<br />";
}
}



function convertListToButtons (data) {
    
    clearConnectList();
    otherClientDiv = document.getElementById('otherClients');
    otherClient2Div = document.getElementById('otherClients2');
    for(var i in data) {
    
        var button = document.createElement('button1');
        button.onclick = function(easyrtcid) {
            return function() {
                performCall(easyrtcid);
            }
        }(i);
        
        
        label = document.createTextNode(view_value);
        btn = document.createElement('button2');
        button.appendChild(btn);
        button.appendChild(label);
        otherClientDiv.appendChild(button);
        }
        
    for(var i2 in data) {

        var button2 = document.createElement('button3');
        button2.onclick = function(easyrtcid) {        
            return function() {
                sendStuffWS(easyrtcid);
            }
        }(i2);
        
        label2 = document.createTextNode("SEND");
        button2.appendChild(label2);
        otherClient2Div.appendChild(button2);
        //button2.appendChild("SEND");


    }
}


function sendStuffWS(otherEasyrtcid) {    
    var text = document.getElementById('sendMessageText').value;    
    if(text.replace(/\s/g, "").length == 0) { // Don't send just whitespace
        return;
    }
    
    easyRTC.sendDataWS(otherEasyrtcid, text);
    addToConversation("ME", text);
    document.getElementById('sendMessageText').value = "";        
}

function hangup() {
    easyRTC.hangupAll();
    disable('hangupButton');
}


function clearConnectList() {
    otherClientDiv = document.getElementById('otherClients');
    while (otherClientDiv.hasChildNodes()) {
        otherClientDiv.removeChild(otherClientDiv.lastChild);
    }
}

               var view_value = getQuerystring('view');
               var sessionID = getQuerystring('session');
               var me = getQuerystring('me');
               
            function getQuerystring(key, default_)
            {
              if (default_==null) default_=""; 
              key = key.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
              var regex = new RegExp("[\\?&]"+key+"=([^&#]*)");
              var qs = regex.exec(window.location.href);
              if(qs == null)
                return default_;
              else
                return qs[1];
            }




function performCall(otherEasyrtcid) {
    easyRTC.hangupAll();
    var acceptedCB = function(accepted, caller) {
        if( !accepted ) {
            alert("Sorry, your call to " + view_value + " was rejected");
            enable('otherClients');
        }
    }
    var successCB = function() {
        enable('hangupButton');
    }
    var failureCB = function() {
        enable('otherClients');
    }
    easyRTC.call(otherEasyrtcid, successCB, failureCB, acceptedCB);
    enable('hangupButton');
}


function loginSuccess(easyRTCId) {
    disable("connectButton");
    // enable("disconnectButton");
    enable('otherClients');
    selfEasyrtcid = easyRTCId;
    document.getElementById("iam").innerHTML = "Conected as: " + easyRTC.cleanId(me);
}


function loginFailure(message) {
    alert("failure to login");
}


function disconnect() {
    document.getElementById("iam").innerHTML = "logged out";
    easyRTC.disconnect();
    console.log("disconnecting from server");
    enable("connectButton");
    // disable("disconnectButton");
    clearConnectList();
    easyRTC.setVideoObjectSrc(document.getElementById('selfVideo'), "");
}


easyRTC.setStreamAcceptor( function(caller, stream) {
    var video = document.getElementById('callerVideo');
    easyRTC.setVideoObjectSrc(video,stream);
    console.log("saw video from " + caller);
    enable("hangupButton");
});



easyRTC.setOnStreamClosed( function (caller) {
    easyRTC.setVideoObjectSrc(document.getElementById('callerVideo'), "");
    disable("hangupButton");
});


var callerPending = null;

easyRTC.setCallCancelled( function(caller){
    if( caller == callerPending) {
        document.getElementById('acceptCallBox').style.display = "none";
        callerPending = false;
    }
});


easyRTC.setAcceptChecker(function(caller, cb) {
    document.getElementById('acceptCallBox').style.display = "block";
    callerPending = caller;
    if( easyRTC.getConnectionCount() > 0 ) {
        document.getElementById('acceptCallLabel').innerHTML = "Drop current video interview and accept new from " + view_value  + " ?";
    }
    else {
        document.getElementById('acceptCallLabel').innerHTML = "Do you want to start the video interview with " + view_value + " ?";
    }
    var acceptTheCall = function(wasAccepted) {
        document.getElementById('acceptCallBox').style.display = "none";
        if( wasAccepted && easyRTC.getConnectionCount() > 0 ) {
            easyRTC.hangupAll();
        }
        cb(wasAccepted);
        callerPending = null;
    }
    document.getElementById("callAcceptButton").onclick = function() {
        acceptTheCall(true);
    };
    document.getElementById("callRejectButton").onclick =function() {
        acceptTheCall(false);
    };
} );