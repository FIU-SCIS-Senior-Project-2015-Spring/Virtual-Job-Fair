easyRTC: Upcoming Features
==========================

There are many exciting features we are looking to add to easyRTC in upcoming releases.

General Features
----------------
* TURN server support

API Specific Features
---------------------
* Better cross browser support
* More power for applications to influence webRTC connections

Server Specific Features
------------------------
* Option to minimize easyrtc.js

Demos
-----
* More demos!

Other
-----
* As the specifications and browsers are improved, we'll follow.
