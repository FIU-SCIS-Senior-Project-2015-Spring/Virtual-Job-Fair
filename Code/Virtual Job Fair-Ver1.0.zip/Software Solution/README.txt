Virtual Job Fair was developed by a group of 5 FIU students for the senior project class, CIS 4911:



Details of deploying the software, including database, nodejs server, and the web source, is found in the installation guide.


This project was built using Eclipse and therefore can easily be opened as an Eclipse Project for further development

Testing was done via Selenium.  To setup Selenium with Eclipse, see http://selftechy.com/2011/05/31/setting-up-selenium-with-eclipse