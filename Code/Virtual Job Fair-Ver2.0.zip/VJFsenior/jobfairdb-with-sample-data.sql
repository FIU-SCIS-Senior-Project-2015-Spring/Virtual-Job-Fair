-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 13, 2013 at 08:32 AM
-- Server version: 5.1.69
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jobfairdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE IF NOT EXISTS `application` (
  `jobid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `application_date` varchar(45) NOT NULL,
  `coverletter` text,
  PRIMARY KEY (`jobid`,`userid`),
  KEY `FK_application_jobid_idx` (`jobid`),
  KEY `FK_applcation_userid_idx` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`jobid`, `userid`, `application_date`, `coverletter`) VALUES
(1, 2, '2013-09-11 01:15:09', 'dwdwdwdwd'),
(3, 2, '2013-09-11 23:28:03', 'gte4t'),
(4, 2, '2013-10-11 20:23:08', ''),
(5, 2, '2013-10-22 12:01:16', ''),
(6, 2, '2013-10-22 12:17:18', ''),
(7, 2, '2013-10-28 19:33:29', 'I''m super awesome and relaxed, id love to work there...'),
(8, 24, '2013-12-05 23:09:25', 'hire me'),
(9, 31, '2013-12-12 00:48:04', ''),
(10, 36, '2013-12-12 10:42:04', ''),
(11, 39, '2013-12-12 16:01:44', ''),
(27, 2, '2013-12-13 00:45:17', 'Hello ');

-- --------------------------------------------------------

--
-- Table structure for table `basic_info`
--

CREATE TABLE IF NOT EXISTS `basic_info` (
  `userid` int(11) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `about_me` text,
  `hide_phone` int(11) DEFAULT '0',
  `allowSMS` int(11) DEFAULT '0',
  `validated` int(11) DEFAULT '0',
  `smsCode` int(11) DEFAULT NULL,
  `tries` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `FK_basicinfo_userid_idx` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `basic_info`
--

INSERT INTO `basic_info` (`userid`, `phone`, `city`, `state`, `about_me`, `hide_phone`, `allowSMS`, `validated`, `smsCode`, `tries`) VALUES
(2, '3055464706', 'Miami', 'FL', '', NULL, 1, 0, NULL, 0),
(3, '3055464706', 'Miami', 'Fl', 'My name is pedrito', 1, 0, 0, NULL, 0),
(4, '3055464706', NULL, NULL, NULL, NULL, 1, 0, NULL, 0),
(5, '3055464706', NULL, NULL, NULL, NULL, 1, 0, NULL, 0),
(21, '3055464706', '', '', '', 0, 1, 0, NULL, 0),
(23, '9541234567', NULL, NULL, NULL, 0, 0, 0, NULL, 0),
(24, '5555555555', NULL, NULL, NULL, 0, 0, 0, NULL, 0),
(25, '3055464706', 'Miami', 'Fl', 'I am great', 0, 0, 0, NULL, 0),
(26, '3053387356', 'dwdwd', 'dwdwd', 'adwawddw', 1, 0, 0, NULL, 0),
(27, '30533355678', 'dwdwdwd', 'dwdwd', 'dawdaddddaddwdd', 1, 0, 0, NULL, 0),
(28, '3052201292', 'dwdwdwd', 'dwdw', 'dwdwdwd', 0, 0, 0, NULL, 0),
(29, '3052201292', 'dwdwdwd', 'dwdw', 'dwdwdwd', 1, 1, 0, NULL, 0),
(30, '30554647061', NULL, NULL, NULL, 0, 1, 0, NULL, 0),
(31, '7864060573', NULL, NULL, NULL, 0, 1, 1, NULL, 0),
(32, '3055464706', 'miami', 'FL', 'none', 0, 0, 1, NULL, 0),
(33, '', 'Miami', 'FL', 'Test', 1, 1, 0, NULL, 0),
(36, '3053483549', NULL, NULL, NULL, 0, 1, 0, NULL, 0),
(37, NULL, 'mIAMI', 'fL', '      ', 0, 1, 0, NULL, 0),
(38, '3055464706', 'Miami', 'FLorida', 'About me', 1, 1, 0, NULL, 0),
(39, '3055464706', 'Miami', 'Fl', '', 0, 1, 0, NULL, 0),
(40, NULL, 'Greater Los Angeles Area', '', 'Attended Florida International University', 0, 0, 0, NULL, 0),
(41, '', 'boca', 'fl', 'industry', 0, 0, 0, NULL, 0),
(42, '', NULL, NULL, NULL, 0, 0, 0, NULL, 0),
(43, '954444444', 'la', 'ca', 'ww', 1, 1, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `company_info`
--

CREATE TABLE IF NOT EXISTS `company_info` (
  `FK_userid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `street` varchar(45) DEFAULT NULL,
  `street2` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zipcode` varchar(45) DEFAULT NULL,
  `website` varchar(45) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`FK_userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `company_info`
--

INSERT INTO `company_info` (`FK_userid`, `name`, `street`, `street2`, `city`, `state`, `zipcode`, `website`, `description`) VALUES
(3, 'Assurance', 'wdwadwa', 'wadwdwad', 'wdwdwd', 'wadwd', 'wdwadwad', 'wdwdwdw', 'hello8'),
(4, 'FIU', '11200', '', 'Miami', 'FL', '33028', '', 'Test'),
(6, 'wadad', 'dwadwd', '', 'dwd', 'dwdw', '33185', '', 'wdwwwdwwd'),
(25, 'FIu', '107 ave', '45', 'Miami', 'Fl', '33185', '', 'adawdawdwd dddd'),
(26, 'dwdwd', 'ddwdd', '', 'dwdwd', 'dwdwd', '33185', '', 'dadawdwd'),
(27, 'dwdwd', 'dwdwd', 'dwdwd', 'dwdwdwd', 'dwdwd', '33185', 'ddw', 'wdadawdwd'),
(28, 'dwdwd', 'ddwdwd', '', 'dwdwdwd', 'dwdw', '33185', '', 'dadadadddwd'),
(29, 'dwdwd', 'ddwdwd', '', 'dwdwdwd', 'dwdw', '33185', '', 'dadadadddwd'),
(32, 'CVS', '25', '', 'miami', 'FL', '33185', '', 'dwdwd'),
(33, 'XYZ', '123', '123', 'Miami', 'FL', '330282', '', 'Test'),
(37, 'IBM', '1 street', '', 'mIAMI', 'fL', '33165', '', '    '),
(38, 'IBM', '1 street', '', 'Miami', 'FLorida', '33185', '', 'Description'),
(41, 'ibm', '1234', '', 'boca', 'fl', '33487', 'ibm.com', 'ibm corp'),
(43, 'orable', '1 st', '', 'la', 'ca', '90210', '', 'ww');

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE IF NOT EXISTS `education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `degree` varchar(45) NOT NULL,
  `major` varchar(45) NOT NULL,
  `graduation_date` date NOT NULL,
  `FK_school_id` int(11) DEFAULT NULL,
  `FK_user_id` int(11) DEFAULT NULL,
  `gpa` float DEFAULT NULL,
  `additional_info` text,
  PRIMARY KEY (`id`),
  KEY `FK_student_id_idx` (`FK_user_id`),
  KEY `FK_school_id_idx` (`FK_school_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`id`, `degree`, `major`, `graduation_date`, `FK_school_id`, `FK_user_id`, `gpa`, `additional_info`) VALUES
(1, 'BSCS', 'Computer Science', '2013-12-15', 8, 2, NULL, ''),
(2, 'Computer Science', 'BsC', '2013-12-14', 8, 7, NULL, 'Graduation'),
(3, 'Bachelors', 'Computer Science', '2013-12-18', 1, 23, NULL, 'Honors'),
(4, '', 'Hardware Engineering', '0000-00-00', 9, 36, NULL, ''),
(5, 'MS', 'Software Engineering', '0000-00-00', 10, 36, NULL, ''),
(7, '', '', '2013-12-12', 1, 40, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE IF NOT EXISTS `experience` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FK_userid` int(11) DEFAULT NULL,
  `company_name` varchar(45) DEFAULT NULL,
  `job_title` varchar(45) DEFAULT NULL,
  `job_description` text,
  `startdate` datetime DEFAULT NULL,
  `enddate` datetime DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_experience_user_idx` (`FK_userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`id`, `FK_userid`, `company_name`, `job_title`, `job_description`, `startdate`, `enddate`, `city`, `state`) VALUES
(1, 23, 'IBM', 'Intern', 'Programmer', '2013-12-08 00:00:00', '0000-00-00 00:00:00', 'Boca Raton', 'Florida');

-- --------------------------------------------------------

--
-- Table structure for table `handshake`
--

CREATE TABLE IF NOT EXISTS `handshake` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobid` int(11) DEFAULT NULL,
  `employerid` int(11) NOT NULL,
  `studentid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_handshake_employer_idx` (`employerid`),
  KEY `FK_handshake_student_idx` (`studentid`),
  KEY `FK_handshake_job_idx` (`jobid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `handshake`
--

INSERT INTO `handshake` (`id`, `jobid`, `employerid`, `studentid`) VALUES
(1, 26, 32, 39);

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `title` varchar(45) NOT NULL,
  `FK_poster` int(11) NOT NULL,
  `post_date` datetime NOT NULL,
  `deadline` datetime DEFAULT NULL,
  `description` longtext NOT NULL,
  `compensation` varchar(45) DEFAULT NULL,
  `other_requirements` text,
  `email_notification` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT '1',
  `matches_found` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_job_poster_idx` (`FK_poster`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`id`, `type`, `title`, `FK_poster`, `post_date`, `deadline`, `description`, `compensation`, `other_requirements`, `email_notification`, `active`, `matches_found`) VALUES
(1, 'Part Time', 'heeeee', 3, '2013-09-11 01:14:48', '2013-09-19 00:00:00', 'dawdwadwad', 'dwdwd', NULL, NULL, 0, NULL),
(2, 'Part Time', 'dwadwad', 6, '2013-09-11 23:24:44', '2013-09-03 00:00:00', 'wdawdwdwdwdwd', 'wdwd', NULL, NULL, 0, NULL),
(3, 'Part Time', 'Quality Engineer', 6, '2013-09-11 23:27:45', '2013-12-05 00:00:00', 'dwadw', 'd', NULL, NULL, 0, NULL),
(4, 'Internship', 'dwdwdw', 3, '2013-10-11 20:20:59', '2013-10-17 00:00:00', 'dwddwwdw', '', NULL, NULL, 0, NULL),
(5, 'Full Time', 'dwdw', 3, '2013-10-22 12:00:24', '2013-10-24 00:00:00', 'dwdwdwd', '', NULL, NULL, 0, NULL),
(6, 'Part Time', 'dwddw', 3, '2013-10-22 12:07:57', '2013-10-24 00:00:00', 'dwdwdw', '', NULL, NULL, 0, NULL),
(7, 'Full Time', 'CEO of Caraballo Enterprises', 3, '2013-10-28 19:32:18', '2013-12-31 00:00:00', 'Work in a super fun, relaxed environment', '100000', NULL, NULL, 0, NULL),
(8, 'Full Time', 'Developer', 23, '2013-12-05 23:08:42', '2014-01-31 00:00:00', 'web developer php js', '50000', NULL, NULL, 1, NULL),
(9, 'Part Time', 'Developer', 32, '2013-12-12 00:47:35', '2013-12-12 00:00:00', 'Develop', '', NULL, NULL, 1, NULL),
(10, 'Full Time', 'product manager', 37, '2013-12-12 10:28:32', '2013-12-13 00:00:00', '   ', '50.00 ', NULL, NULL, 1, NULL),
(11, 'Full Time', 'Software Developer', 3, '2013-12-12 15:16:21', '2013-12-14 00:00:00', 'demo', '$25.00', NULL, NULL, 1, NULL),
(12, 'Full Time', 'Developer', 3, '2013-12-12 15:29:48', '2013-12-14 00:00:00', 'descp', '$25.00', NULL, NULL, 0, NULL),
(13, 'Full Time', 'dev1', 3, '2013-12-12 16:54:40', '2013-12-12 00:00:00', 'Great', '', NULL, NULL, 1, NULL),
(14, 'Part Time', 'java developer', 3, '2013-12-12 19:37:02', '2013-12-20 00:00:00', 'java c# javascript', '', NULL, NULL, 1, NULL),
(15, 'Part Time', 'Software Developer', 3, '2013-12-12 19:37:48', '2013-12-12 00:00:00', 'Here is a ', '', NULL, NULL, 1, NULL),
(16, 'Full Time', 'Software Developer 2', 3, '2013-12-12 19:38:51', '2013-12-19 00:00:00', 'ajax', 'd', NULL, NULL, 0, NULL),
(17, 'Full Time', 'Web intern', 3, '2013-12-12 19:45:17', '2013-12-13 00:00:00', 'ajax', '', NULL, NULL, 1, NULL),
(18, 'Part Time', 'Developer', 3, '2013-12-12 19:46:00', '2013-12-13 00:00:00', 'ajax ', '', NULL, NULL, 1, NULL),
(19, 'Full Time', 'test3', 3, '2013-12-12 19:46:27', '2013-12-13 00:00:00', 'Hey bro', '', NULL, NULL, 0, NULL),
(20, 'Part Time', 'd', 3, '2013-12-12 19:47:12', '2013-12-21 00:00:00', 'try again', '', NULL, NULL, 0, NULL),
(21, 'Full Time', 'j', 3, '2013-12-12 20:17:27', '2013-12-26 00:00:00', 'ajax ', '', NULL, NULL, 0, NULL),
(22, 'Full Time', 'developer', 3, '2013-12-12 20:18:41', '2013-12-31 00:00:00', 'super well paid', '1000', NULL, NULL, 1, NULL),
(23, 'Full Time', 'engineer', 3, '2013-12-12 20:21:28', '2013-12-31 00:00:00', 'awesome job', '25.00', NULL, NULL, 1, NULL),
(24, 'Internship', 'Programmer1', 41, '2013-12-12 20:58:08', '2013-12-27 00:00:00', 'Internship for a programmer', '', NULL, NULL, 1, NULL),
(25, 'Part Time', 'Architect', 3, '2013-12-12 22:42:10', '2013-12-21 00:00:00', 'Java Ajax', '25.00', NULL, NULL, 1, NULL),
(26, 'Internship', 'Web development internship', 32, '2013-12-12 23:09:37', '2013-12-20 00:00:00', 'php ajax javascript . Website development', '17.00', NULL, NULL, 1, NULL),
(27, 'Part Time', 'QA Engineer', 32, '2013-12-13 00:43:11', '2013-12-16 00:00:00', 'java c ', '25.00', NULL, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `job_skill_map`
--

CREATE TABLE IF NOT EXISTS `job_skill_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jobid` int(11) NOT NULL,
  `skillid` int(11) NOT NULL,
  `level` varchar(45) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_job_skill_idx` (`jobid`),
  KEY `FK_job_skill_skillid_idx` (`skillid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `job_skill_map`
--

INSERT INTO `job_skill_map` (`id`, `jobid`, `skillid`, `level`, `ordering`) VALUES
(1, 1, 1, NULL, 1),
(2, 3, 1, NULL, 1),
(3, 4, 1, NULL, 1),
(4, 5, 1, NULL, 1),
(5, 6, 1, NULL, 1),
(6, 7, 54, NULL, 1),
(7, 8, 3, NULL, 1),
(8, 10, 33, NULL, 1),
(9, 11, 25, NULL, 1),
(10, 11, 33, NULL, 2),
(11, 12, 33, NULL, 1),
(12, 13, 32, NULL, 1),
(13, 13, 33, NULL, 2),
(14, 14, 33, NULL, 1),
(15, 14, 1, NULL, 2),
(16, 14, 16, NULL, 3),
(17, 15, 25, NULL, 1),
(18, 16, 25, NULL, 1),
(19, 17, 25, NULL, 1),
(20, 18, 25, NULL, 1),
(21, 19, 25, NULL, 1),
(22, 19, 33, NULL, 2),
(23, 20, 25, NULL, 1),
(24, 20, 33, NULL, 2),
(25, 21, 25, NULL, 1),
(26, 22, 54, NULL, 1),
(27, 23, 1, NULL, 1),
(28, 24, 1, NULL, 1),
(29, 24, 16, NULL, 2),
(30, 24, 33, NULL, 3),
(31, 24, 41, NULL, 4),
(32, 24, 32, NULL, 5),
(33, 25, 1, NULL, 1),
(34, 25, 25, NULL, 2),
(35, 26, 3, NULL, 1),
(36, 26, 25, NULL, 2),
(37, 26, 16, NULL, 3),
(38, 27, 1, NULL, 1),
(39, 27, 33, NULL, 2),
(40, 27, 52, NULL, 3),
(41, 27, 54, NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FK_receiver` varchar(45) NOT NULL,
  `FK_sender` varchar(45) NOT NULL,
  `message` text,
  `date` datetime DEFAULT NULL,
  `been_read` int(11) DEFAULT '0',
  `been_deleted` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(255) DEFAULT NULL,
  `userImage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_receiver_idx` (`FK_receiver`),
  KEY `FK_sender_idx` (`FK_sender`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `FK_receiver`, `FK_sender`, `message`, `date`, `been_read`, `been_deleted`, `subject`, `userImage`) VALUES
(1, 'hello5', 'hello8', 'hello sire', '2013-09-11 21:43:47', 1, 0, 'dwdw', '/JobFair/images/profileimages/avatarsmall.gif'),
(2, 'hello5', 'Wayne001', 'Thank you', '2013-12-13 00:46:27', 1, 0, 'Hey', '/JobFair/images/profileimages/avatarsmall.gif');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `datetime` time NOT NULL,
  `been_read` int(11) NOT NULL DEFAULT '0',
  `message` varchar(5000) DEFAULT NULL,
  `link` varchar(150) DEFAULT NULL,
  `importancy` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_idx` (`sender_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=450 ;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `sender_id`, `receiver_id`, `datetime`, `been_read`, `message`, `link`, `importancy`) VALUES
(1, 3, 2, '01:12:57', 1, 'hello8 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hello8', 1),
(2, 3, 1, '01:12:57', 0, 'There is a new employer named hello8 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hello8', 1),
(3, 3, 2, '01:14:48', 1, 'hello8 just posted a new job: heeeee. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/1', 1),
(4, 2, 3, '01:15:09', 1, 'The User hello5 just applied for your job heeeee. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/hello5', 6),
(24, 3, 7, '20:21:00', 0, 'hello8 just posted a new job: dwdwdw. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/4', 1),
(23, 3, 2, '20:21:00', 0, 'hello8 just posted a new job: dwdwdw. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/4', 1),
(8, 4, 1, '21:52:33', 0, 'There is a new employer named liriz002 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/liriz002', 1),
(11, 3, 2, '22:20:19', 1, 'hello8 scheduled a video interview with you on: 2013-09-12 at: 22:25 Good Lucky!', 'hello8', 4),
(9, 3, 2, '22:17:19', 1, 'hello8 scheduled a video interview with you on: 2013-09-12 at: 22:45 Good Lucky!', 'hello8', 4),
(15, 3, 2, '22:41:14', 1, 'hello8 scheduled a video interview with you on: 2013-09-12 at: 22:43 Good Lucky!', 'hello8', 4),
(13, 3, 2, '22:26:39', 1, 'hello8 scheduled a video interview with you on: 2013-09-12 at: 22:29 Good Lucky!', 'hello8', 4),
(16, 2, 3, '22:41:14', 1, 'You scheduled an interview with hello5 at 22:43 on 2013-09-12 Click here to go to the interview page.', 'hello5', 4),
(26, 2, 3, '20:23:08', 1, 'The User hello5 just applied for your job dwdwdw. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/hello5', 6),
(18, 6, 1, '23:16:45', 0, 'There is a new employer named hello89 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hello89', 1),
(29, 3, 2, '12:00:24', 1, 'hello8 just posted a new job: dwdw. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/5', 1),
(28, 2, 3, '20:37:59', 1, 'You scheduled an interview with hello5 at 02:00 on 2013-10-12 Click here to go to the interview page.', 'hello5', 4),
(25, 3, 2, '20:21:00', 1, 'Hi hello5, the company hello8 just posted a job dwdwdw that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/4', 2),
(33, 2, 3, '12:01:16', 1, 'The User hello5 just applied for your job dwdw. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/hello5', 6),
(22, 2, 6, '23:28:03', 0, 'The User hello5 just applied for your job Car. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/hello5', 6),
(30, 3, 7, '12:00:24', 0, 'hello8 just posted a new job: dwdw. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/5', 1),
(31, 3, 8, '12:00:24', 0, 'hello8 just posted a new job: dwdw. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/5', 1),
(32, 3, 2, '12:00:24', 1, 'Hi hello5, the company hello8 just posted a job dwdw that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/5', 2),
(34, 3, 2, '12:01:41', 1, 'hello8 scheduled a video interview with you on: 2013-10-31 at: 01:00 Good Lucky!', 'hello8', 4),
(35, 2, 3, '12:01:41', 1, 'You scheduled an interview with hello5 at 01:00 on 2013-10-31 Click here to go to the interview page.', 'hello5', 4),
(36, 3, 2, '12:07:57', 1, 'hello8 just posted a new job: dwddw. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/6', 1),
(37, 3, 7, '12:07:57', 0, 'hello8 just posted a new job: dwddw. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/6', 1),
(38, 3, 8, '12:07:57', 0, 'hello8 just posted a new job: dwddw. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/6', 1),
(39, 3, 2, '12:07:57', 1, 'Hi hello5, the company hello8 just posted a job dwddw that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/6', 2),
(40, 2, 3, '12:17:18', 1, 'The User hello5 just applied for your job dwddw. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/hello5', 6),
(41, 3, 2, '12:17:49', 1, 'hello8 scheduled a video interview with you on: 2013-10-31 at: 01:00 Good Lucky!', 'hello8', 4),
(42, 2, 3, '12:17:49', 1, 'You scheduled an interview with hello5 at 01:00 on 2013-10-31 Click here to go to the interview page.', 'hello5', 4),
(43, 3, 2, '19:32:18', 0, 'hello8 just posted a new job: CEO of Caraballo Enterprises. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/7', 1),
(44, 3, 7, '19:32:18', 0, 'hello8 just posted a new job: CEO of Caraballo Enterprises. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/7', 1),
(45, 3, 8, '19:32:18', 0, 'hello8 just posted a new job: CEO of Caraballo Enterprises. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/7', 1),
(46, 3, 19, '19:32:18', 0, 'hello8 just posted a new job: CEO of Caraballo Enterprises. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/7', 1),
(47, 3, 2, '19:32:18', 1, 'Hi hello5, the company hello8 just posted a job CEO of Caraballo Enterprises that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/7', 2),
(48, 2, 3, '19:33:29', 1, 'The User hello5 just applied for your job CEO of Caraballo Enterprises. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/hello5', 6),
(49, 23, 2, '23:08:42', 0, 'jdoe just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/8', 1),
(50, 23, 7, '23:08:42', 0, 'jdoe just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/8', 1),
(51, 23, 8, '23:08:42', 0, 'jdoe just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/8', 1),
(52, 23, 19, '23:08:42', 0, 'jdoe just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/8', 1),
(53, 23, 21, '23:08:42', 0, 'jdoe just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/8', 1),
(54, 23, 22, '23:08:42', 0, 'jdoe just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/8', 1),
(55, 23, 24, '23:08:42', 0, 'jdoe just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/8', 1),
(56, 23, 2, '23:08:42', 1, 'Hi hello5, the company jdoe just posted a job Developer that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/8', 2),
(57, 24, 23, '23:09:25', 1, 'The User janedoe001 just applied for your job Developer. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/janedoe001', 6),
(58, 23, 24, '23:09:53', 1, 'jdoe scheduled a video interview with you on: 2014-01-31 at: 13:00 Good Luck!', 'jdoe', 4),
(59, 24, 23, '23:09:53', 1, 'You scheduled an interview with janedoe001 at 13:00 on 2014-01-31 Click here to go to the interview page.', 'janedoe001', 4),
(170, 3, 7, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(61, 25, 7, '11:21:26', 0, 'Johnk just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johnk', 1),
(62, 25, 8, '11:21:26', 0, 'Johnk just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johnk', 1),
(63, 25, 19, '11:21:26', 0, 'Johnk just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johnk', 1),
(64, 25, 21, '11:21:26', 0, 'Johnk just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johnk', 1),
(65, 25, 22, '11:21:26', 0, 'Johnk just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johnk', 1),
(66, 25, 24, '11:21:26', 0, 'Johnk just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johnk', 1),
(67, 25, 1, '11:21:26', 0, 'There is a new employer named Johnk that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johnk', 1),
(68, 25, 5, '11:21:26', 0, 'There is a new employer named Johnk that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johnk', 1),
(69, 26, 2, '11:24:46', 0, 'hik25 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hik25', 1),
(70, 26, 7, '11:24:46', 0, 'hik25 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hik25', 1),
(71, 26, 8, '11:24:46', 0, 'hik25 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hik25', 1),
(72, 26, 19, '11:24:46', 0, 'hik25 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hik25', 1),
(73, 26, 21, '11:24:46', 0, 'hik25 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hik25', 1),
(74, 26, 22, '11:24:46', 0, 'hik25 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hik25', 1),
(75, 26, 24, '11:24:46', 0, 'hik25 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hik25', 1),
(76, 26, 1, '11:24:46', 0, 'There is a new employer named hik25 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hik25', 1),
(77, 26, 5, '11:24:46', 0, 'There is a new employer named hik25 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/hik25', 1),
(78, 27, 2, '11:40:27', 0, 'working just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/working', 1),
(79, 27, 7, '11:40:27', 0, 'working just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/working', 1),
(80, 27, 8, '11:40:27', 0, 'working just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/working', 1),
(81, 27, 19, '11:40:27', 0, 'working just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/working', 1),
(82, 27, 21, '11:40:27', 0, 'working just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/working', 1),
(83, 27, 22, '11:40:27', 0, 'working just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/working', 1),
(84, 27, 24, '11:40:27', 0, 'working just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/working', 1),
(85, 27, 1, '11:40:27', 0, 'There is a new employer named working that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/working', 1),
(86, 27, 5, '11:40:27', 0, 'There is a new employer named working that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/working', 1),
(87, 28, 2, '11:44:01', 0, 'john just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john', 1),
(88, 28, 7, '11:44:01', 0, 'john just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john', 1),
(89, 28, 8, '11:44:01', 0, 'john just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john', 1),
(90, 28, 19, '11:44:01', 0, 'john just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john', 1),
(91, 28, 21, '11:44:01', 0, 'john just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john', 1),
(92, 28, 22, '11:44:01', 0, 'john just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john', 1),
(93, 28, 24, '11:44:01', 0, 'john just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john', 1),
(94, 28, 1, '11:44:01', 0, 'There is a new employer named john that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john', 1),
(95, 28, 5, '11:44:01', 0, 'There is a new employer named john that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john', 1),
(96, 29, 2, '11:45:02', 0, 'john1 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john1', 1),
(97, 29, 7, '11:45:02', 0, 'john1 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john1', 1),
(98, 29, 8, '11:45:02', 0, 'john1 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john1', 1),
(99, 29, 19, '11:45:02', 0, 'john1 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john1', 1),
(100, 29, 21, '11:45:02', 0, 'john1 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john1', 1),
(101, 29, 22, '11:45:02', 0, 'john1 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john1', 1),
(102, 29, 24, '11:45:02', 0, 'john1 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john1', 1),
(103, 29, 1, '11:45:02', 0, 'There is a new employer named john1 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john1', 1),
(104, 29, 5, '11:45:02', 0, 'There is a new employer named john1 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/john1', 1),
(105, 32, 2, '00:43:16', 0, 'Wayne001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(106, 32, 7, '00:43:16', 0, 'Wayne001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(107, 32, 8, '00:43:16', 0, 'Wayne001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(108, 32, 19, '00:43:16', 0, 'Wayne001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(109, 32, 21, '00:43:16', 0, 'Wayne001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(110, 32, 22, '00:43:16', 0, 'Wayne001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(111, 32, 24, '00:43:16', 0, 'Wayne001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(112, 32, 30, '00:43:16', 0, 'Wayne001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(113, 32, 31, '00:43:16', 0, 'Wayne001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(114, 32, 1, '00:43:16', 1, 'There is a new employer named Wayne001 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(115, 32, 5, '00:43:16', 0, 'There is a new employer named Wayne001 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Wayne001', 1),
(116, 32, 2, '00:47:35', 0, 'Wayne001 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/9', 1),
(117, 32, 7, '00:47:35', 0, 'Wayne001 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/9', 1),
(118, 32, 8, '00:47:35', 0, 'Wayne001 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/9', 1),
(119, 32, 19, '00:47:35', 0, 'Wayne001 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/9', 1),
(120, 32, 21, '00:47:35', 0, 'Wayne001 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/9', 1),
(121, 32, 22, '00:47:35', 0, 'Wayne001 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/9', 1),
(122, 32, 24, '00:47:35', 0, 'Wayne001 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/9', 1),
(123, 32, 30, '00:47:35', 0, 'Wayne001 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/9', 1),
(124, 32, 31, '00:47:35', 0, 'Wayne001 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/9', 1),
(125, 31, 32, '00:48:04', 1, 'The User clau001 just applied for your job Developer. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/clau001', 6),
(126, 32, 31, '00:48:44', 1, 'Wayne001 scheduled a video interview with you on: 2013-12-13 at: 14:00 Good Luck!', 'Wayne001', 4),
(127, 31, 32, '00:48:44', 1, 'You scheduled an interview with clau001 at 14:00 on 2013-12-13 Click here to go to the interview page.', 'clau001', 4),
(166, 36, 37, '10:42:04', 1, 'The User msadjadi just applied for your job product manager. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/msadjadi', 6),
(129, 33, 7, '01:38:34', 0, 'laib just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(130, 33, 8, '01:38:34', 0, 'laib just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(131, 33, 19, '01:38:34', 0, 'laib just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(132, 33, 21, '01:38:34', 0, 'laib just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(133, 33, 22, '01:38:34', 0, 'laib just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(134, 33, 24, '01:38:34', 0, 'laib just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(135, 33, 30, '01:38:34', 0, 'laib just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(136, 33, 31, '01:38:34', 0, 'laib just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(137, 33, 1, '01:38:34', 0, 'There is a new employer named laib that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(138, 33, 5, '01:38:34', 0, 'There is a new employer named laib that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/laib', 1),
(140, 2, 33, '01:41:13', 1, 'You scheduled an interview with hello5 at 01:42 on 2013-12-14 Click here to go to the interview page.', 'hello5', 4),
(141, 33, 23, '01:42:37', 0, 'laib scheduled a video interview with you on: 2013-12-14 at: 16:02 Good Luck!', 'laib', 4),
(142, 23, 33, '01:42:37', 1, 'You scheduled an interview with jdoe at 16:02 on 2013-12-14 Click here to go to the interview page.', 'jdoe', 4),
(169, 3, 2, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(167, 37, 36, '10:43:18', 1, 'caraballo001 scheduled a video interview with you on: 2013-12-13 at: 01:00 Good Luck!', 'caraballo001', 4),
(144, 37, 7, '10:26:58', 0, 'caraballo001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(145, 37, 8, '10:26:58', 0, 'caraballo001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(146, 37, 21, '10:26:58', 0, 'caraballo001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(147, 37, 22, '10:26:58', 0, 'caraballo001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(148, 37, 24, '10:26:58', 0, 'caraballo001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(149, 37, 30, '10:26:58', 0, 'caraballo001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(150, 37, 31, '10:26:58', 0, 'caraballo001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(151, 37, 35, '10:26:58', 0, 'caraballo001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(152, 37, 36, '10:26:58', 0, 'caraballo001 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(153, 37, 1, '10:26:58', 1, 'There is a new employer named caraballo001 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(154, 37, 5, '10:26:58', 0, 'There is a new employer named caraballo001 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/caraballo001', 1),
(168, 36, 37, '10:43:18', 1, 'You scheduled an interview with msadjadi at 01:00 on 2013-12-13 Click here to go to the interview page.', 'msadjadi', 4),
(156, 37, 7, '10:28:32', 0, 'caraballo001 just posted a new job: product manager. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/10', 1),
(157, 37, 8, '10:28:32', 0, 'caraballo001 just posted a new job: product manager. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/10', 1),
(158, 37, 21, '10:28:32', 0, 'caraballo001 just posted a new job: product manager. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/10', 1),
(159, 37, 22, '10:28:32', 0, 'caraballo001 just posted a new job: product manager. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/10', 1),
(160, 37, 24, '10:28:32', 0, 'caraballo001 just posted a new job: product manager. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/10', 1),
(161, 37, 30, '10:28:32', 0, 'caraballo001 just posted a new job: product manager. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/10', 1),
(162, 37, 31, '10:28:32', 0, 'caraballo001 just posted a new job: product manager. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/10', 1),
(163, 37, 35, '10:28:32', 0, 'caraballo001 just posted a new job: product manager. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/10', 1),
(164, 37, 36, '10:28:32', 0, 'caraballo001 just posted a new job: product manager. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/10', 1),
(402, 3, 2, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(171, 3, 8, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(172, 3, 21, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(173, 3, 22, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(174, 3, 24, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(175, 3, 30, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(176, 3, 31, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(177, 3, 35, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(178, 3, 36, '15:16:21', 0, 'hello8 just posted a new job: Software Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/11', 1),
(403, 3, 7, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(404, 3, 8, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(405, 3, 21, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(182, 3, 2, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(183, 3, 7, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(184, 3, 8, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(185, 3, 21, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(186, 3, 22, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(187, 3, 24, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(188, 3, 30, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(189, 3, 31, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(190, 3, 35, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(191, 3, 36, '15:29:48', 0, 'hello8 just posted a new job: Developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/12', 1),
(406, 3, 22, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(193, 3, 2, '15:32:04', 1, 'hello8 scheduled a video interview with you on: 2013-12-13 at: 01:00 Good Luck!', 'hello8', 4),
(194, 2, 3, '15:32:04', 0, 'You scheduled an interview with hello5 at 01:00 on 2013-12-13 Click here to go to the interview page.', 'hello5', 4),
(195, 38, 2, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(196, 38, 7, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(197, 38, 8, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(198, 38, 21, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(199, 38, 22, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(200, 38, 24, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(201, 38, 30, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(202, 38, 31, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(203, 38, 35, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(204, 38, 36, '15:49:09', 0, 'Johns just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(205, 38, 1, '15:49:09', 0, 'There is a new employer named Johns that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(206, 38, 5, '15:49:09', 0, 'There is a new employer named Johns that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/Johns', 1),
(207, 39, 3, '16:01:44', 1, 'The User jfern096 just applied for your job Software Developer. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/jfern096', 6),
(208, 3, 39, '16:07:25', 0, 'hello8 scheduled a video interview with you on: 2013-12-13 at: 01:00 Good Luck!', 'hello8', 4),
(209, 39, 3, '16:07:25', 1, 'You scheduled an interview with jfern096 at 01:00 on 2013-12-13 Click here to go to the interview page.', 'jfern096', 4),
(210, 3, 2, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(211, 3, 7, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(212, 3, 8, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(213, 3, 21, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(214, 3, 22, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(215, 3, 24, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(216, 3, 30, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(217, 3, 31, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(218, 3, 35, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(219, 3, 36, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(220, 3, 39, '16:54:40', 0, 'hello8 just posted a new job: dev1. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 1),
(221, 3, 39, '16:54:41', 0, 'Hi jfern096, the company hello8 just posted a job dev1 that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/13', 2),
(407, 3, 24, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(223, 41, 2, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(224, 41, 7, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(225, 41, 8, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(226, 41, 21, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(227, 41, 22, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(228, 41, 24, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(229, 41, 30, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(230, 41, 31, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(231, 41, 35, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(232, 41, 36, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(233, 41, 39, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(234, 41, 40, '19:35:05', 0, 'juanc just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(235, 41, 1, '19:35:05', 1, 'There is a new employer named juanc that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(236, 41, 5, '19:35:05', 0, 'There is a new employer named juanc that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/juanc', 1),
(237, 3, 2, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(238, 3, 7, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(239, 3, 8, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(240, 3, 21, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(241, 3, 22, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(242, 3, 24, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(243, 3, 30, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(244, 3, 31, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(245, 3, 35, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(246, 3, 36, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(247, 3, 39, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(248, 3, 40, '19:37:02', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 1),
(408, 3, 30, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(250, 3, 39, '19:37:02', 0, 'Hi jfern096, the company hello8 just posted a job c that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/14', 2),
(251, 3, 2, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(252, 3, 7, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(253, 3, 8, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(254, 3, 21, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(255, 3, 22, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(256, 3, 24, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(257, 3, 30, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(258, 3, 31, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(259, 3, 35, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(260, 3, 36, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(261, 3, 39, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(262, 3, 40, '19:37:48', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 1),
(263, 3, 39, '19:37:49', 0, 'Hi jfern096, the company hello8 just posted a job d that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/15', 2),
(409, 3, 31, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(265, 3, 2, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(266, 3, 7, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(267, 3, 8, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(268, 3, 21, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(269, 3, 22, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(270, 3, 24, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(271, 3, 30, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(272, 3, 31, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(273, 3, 35, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(274, 3, 36, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(275, 3, 39, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(276, 3, 40, '19:38:51', 0, 'hello8 just posted a new job: c. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 1),
(277, 3, 39, '19:38:52', 0, 'Hi jfern096, the company hello8 just posted a job c that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/16', 2),
(410, 3, 35, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(279, 3, 2, '19:45:17', 1, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(280, 3, 7, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(281, 3, 8, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(282, 3, 21, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(283, 3, 22, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(284, 3, 24, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(285, 3, 30, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(286, 3, 31, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(287, 3, 35, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(288, 3, 36, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(289, 3, 39, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(290, 3, 40, '19:45:17', 0, 'hello8 just posted a new job: test. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 1),
(291, 3, 39, '19:45:17', 0, 'Hi jfern096, the company hello8 just posted a job test that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/17', 2),
(292, 3, 2, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(293, 3, 7, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(294, 3, 8, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(295, 3, 21, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(296, 3, 22, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(297, 3, 24, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(298, 3, 30, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(299, 3, 31, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(300, 3, 35, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(301, 3, 36, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1);
INSERT INTO `notification` (`id`, `sender_id`, `receiver_id`, `datetime`, `been_read`, `message`, `link`, `importancy`) VALUES
(302, 3, 39, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(303, 3, 40, '19:46:00', 0, 'hello8 just posted a new job: test2. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 1),
(304, 3, 39, '19:46:01', 0, 'Hi jfern096, the company hello8 just posted a job test2 that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/18', 2),
(411, 3, 36, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(306, 3, 2, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(307, 3, 7, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(308, 3, 8, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(309, 3, 21, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(310, 3, 22, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(311, 3, 24, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(312, 3, 30, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(313, 3, 31, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(314, 3, 35, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(315, 3, 36, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(316, 3, 39, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(317, 3, 40, '19:46:27', 0, 'hello8 just posted a new job: test3. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 1),
(318, 3, 39, '19:46:27', 0, 'Hi jfern096, the company hello8 just posted a job test3 that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/19', 2),
(412, 3, 39, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(320, 3, 2, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(321, 3, 7, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(322, 3, 8, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(323, 3, 21, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(324, 3, 22, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(325, 3, 24, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(326, 3, 30, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(327, 3, 31, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(328, 3, 35, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(329, 3, 36, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(330, 3, 39, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(331, 3, 40, '19:47:12', 0, 'hello8 just posted a new job: d. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 1),
(332, 3, 39, '19:47:12', 0, 'Hi jfern096, the company hello8 just posted a job d that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/20', 2),
(333, 3, 2, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(334, 3, 7, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(335, 3, 8, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(336, 3, 21, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(337, 3, 22, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(338, 3, 24, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(339, 3, 30, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(340, 3, 31, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(341, 3, 35, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(342, 3, 36, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(343, 3, 39, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(344, 3, 40, '20:17:27', 0, 'hello8 just posted a new job: j. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 1),
(345, 3, 39, '20:17:27', 0, 'Hi jfern096, the company hello8 just posted a job j that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/21', 2),
(346, 3, 2, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(347, 3, 7, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(348, 3, 8, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(349, 3, 21, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(350, 3, 22, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(351, 3, 24, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(352, 3, 30, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(353, 3, 31, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(354, 3, 35, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(355, 3, 36, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(356, 3, 39, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(357, 3, 40, '20:18:41', 0, 'hello8 just posted a new job: developer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/22', 1),
(358, 3, 2, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(359, 3, 7, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(360, 3, 8, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(361, 3, 21, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(362, 3, 22, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(363, 3, 24, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(364, 3, 30, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(365, 3, 31, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(366, 3, 35, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(367, 3, 36, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(368, 3, 39, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(369, 3, 40, '20:21:28', 0, 'hello8 just posted a new job: engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 1),
(413, 3, 40, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(371, 3, 39, '20:21:29', 0, 'Hi jfern096, the company hello8 just posted a job engineer that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/23', 2),
(372, 43, 2, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(373, 43, 7, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(374, 43, 8, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(375, 43, 21, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(376, 43, 22, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(377, 43, 24, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(378, 43, 30, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(379, 43, 31, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(380, 43, 35, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(381, 43, 36, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(382, 43, 39, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(383, 43, 40, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(384, 43, 42, '20:47:15', 0, 'jtb01 just joined VJF, click here to view their profile.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(385, 43, 1, '20:47:15', 1, 'There is a new employer named jtb01 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(386, 43, 5, '20:47:15', 0, 'There is a new employer named jtb01 that is waiting for acctivation', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/employer/user/jtb01', 1),
(387, 41, 2, '20:58:08', 1, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(388, 41, 7, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(389, 41, 8, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(390, 41, 21, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(391, 41, 22, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(392, 41, 24, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(393, 41, 30, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(394, 41, 31, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(395, 41, 35, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(396, 41, 36, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(397, 41, 39, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(398, 41, 40, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(399, 41, 42, '20:58:08', 0, 'juanc just posted a new job: Programmer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 1),
(414, 3, 42, '22:42:10', 0, 'hello8 just posted a new job: Architect. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 1),
(401, 41, 39, '20:58:09', 0, 'Hi jfern096, the company juanc just posted a job Programmer that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/24', 2),
(415, 3, 39, '22:42:10', 0, 'Hi jfern096, the company hello8 just posted a job Architect that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 2),
(416, 3, 2, '22:42:10', 0, 'Hi hello5, the company hello8 just posted a job Architect that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/25', 2),
(417, 32, 2, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(418, 32, 7, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(419, 32, 8, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(420, 32, 21, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(421, 32, 22, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(422, 32, 24, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(423, 32, 30, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(424, 32, 31, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(425, 32, 35, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(426, 32, 36, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(427, 32, 39, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(428, 32, 40, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(429, 32, 42, '23:09:37', 0, 'Wayne001 just posted a new job: Web development internship. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 1),
(430, 32, 39, '23:09:37', 0, 'Hi jfern096, the company Wayne001 just posted a job Web development internship that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 2),
(431, 32, 39, '23:09:46', 0, 'Wayne001 is interested in you for the following job post: Web development internship Click here to view the post and consider applying.', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/26', 2),
(432, 32, 2, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(433, 32, 7, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(434, 32, 8, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(435, 32, 21, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(436, 32, 22, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(437, 32, 24, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(438, 32, 30, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(439, 32, 31, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(440, 32, 35, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(441, 32, 36, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(442, 32, 39, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(443, 32, 40, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(444, 32, 42, '00:43:11', 0, 'Wayne001 just posted a new job: QA Engineer. Click here to view the post. ', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 1),
(445, 32, 39, '00:43:11', 0, 'Hi jfern096, the company Wayne001 just posted a job QA Engineer that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 2),
(446, 32, 2, '00:43:11', 0, 'Hi hello5, the company Wayne001 just posted a job QA Engineer that matches your skills', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/job/view/jobid/27', 2),
(447, 2, 32, '00:45:17', 1, 'The User hello5 just applied for your job QA Engineer. Click here to view his profile', 'http://srprog-fall13-01.cs.fiu.edu/JobFair/index.php/profile/student/user/hello5', 6),
(448, 32, 2, '00:48:16', 1, 'Wayne001 scheduled a video interview with you on: 2013-12-14 at: 01:00 Good Luck!', 'Wayne001', 4),
(449, 2, 32, '00:48:16', 1, 'You scheduled an interview with hello5 at 01:00 on 2013-12-14 Click here to go to the interview page.', 'hello5', 4);

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE IF NOT EXISTS `resume` (
  `id` int(11) NOT NULL,
  `resume` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `resume`
--

INSERT INTO `resume` (`id`, `resume`) VALUES
(2, '/JobFair/resumes/2-1.2.2-BusinessEcon.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE IF NOT EXISTS `school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email_string` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`id`, `name`, `email_string`) VALUES
(1, 'Florida International University', NULL),
(2, 'Miami Dade College', NULL),
(4, 'University of Miami', NULL),
(5, 'University of Florida', NULL),
(6, 'University of Central Florida', NULL),
(7, 'Florida State University', NULL),
(8, 'FIu', NULL),
(9, 'University of Tehran', NULL),
(10, 'Azad University (Tehran)', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `skillset`
--

CREATE TABLE IF NOT EXISTS `skillset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `skillset`
--

INSERT INTO `skillset` (`id`, `name`) VALUES
(25, 'AJAX'),
(32, 'Android Development'),
(54, 'assembly'),
(33, 'C'),
(52, 'c socket programing'),
(50, 'C++'),
(17, 'CSS'),
(13, 'Customer Satisfaction'),
(11, 'Customer Service'),
(36, 'Database Design'),
(53, 'F#'),
(6, 'High Availability'),
(8, 'HTML'),
(41, 'iOS Development'),
(40, 'iPhone Application Development'),
(1, 'Java'),
(16, 'JavaScript'),
(27, 'jQuery'),
(38, 'JSP'),
(34, 'LAMP'),
(20, 'Linux'),
(42, 'Microsoft Excel'),
(12, 'Microsoft Office'),
(43, 'Microsoft Word'),
(28, 'MVC'),
(14, 'MySQL'),
(39, 'Objective-C'),
(9, 'OS X'),
(46, 'Photoshop'),
(3, 'PHP'),
(15, 'PL/SQL'),
(21, 'PostgreSQL'),
(44, 'PowerPoint'),
(49, 'Public Speaking'),
(37, 'Relational Databases'),
(45, 'Research'),
(51, 'Ruby on Rails'),
(19, 'Selenium'),
(47, 'Social Media'),
(2, 'SQL'),
(10, 'Team Leadership'),
(48, 'Teamwork'),
(24, 'Unix'),
(29, 'Web Development'),
(18, 'Web Page Automation'),
(7, 'Windows'),
(31, 'Wordpress'),
(30, 'Yii');

-- --------------------------------------------------------

--
-- Table structure for table `SMS`
--

CREATE TABLE IF NOT EXISTS `SMS` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `date` datetime DEFAULT NULL,
  `subject` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Message` text CHARACTER SET utf8,
  PRIMARY KEY (`id`),
  KEY `receiver_id` (`receiver_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=88 ;

--
-- Dumping data for table `SMS`
--

INSERT INTO `SMS` (`id`, `receiver_id`, `sender_id`, `date`, `subject`, `Message`) VALUES
(76, 2, 3, '2013-11-02 13:49:24', NULL, 'Hey'),
(77, 2, 3, '2013-11-02 13:50:05', NULL, 'dw'),
(78, 2, 3, '2013-11-02 13:50:36', NULL, 'dw'),
(79, 2, 3, '2013-11-02 13:57:22', NULL, 'dw'),
(80, 2, 3, '2013-11-03 18:01:49', NULL, 'hi'),
(81, 2, 3, '2013-11-03 18:06:37', NULL, 'hey'),
(82, 3, 3, '2013-11-21 12:45:18', NULL, 'VJF Message from hello8 \nQue bola'),
(83, 3, 3, '2013-12-09 10:55:47', NULL, 'VJF Message from hello8 \nhi'),
(84, 2, 3, '2013-12-11 18:15:29', NULL, 'VJF Message from hello8 \nlol'),
(85, 2, 3, '2013-12-11 18:20:01', NULL, 'VJF Message from hello8 \nlol'),
(86, 31, 32, '2013-12-12 00:51:55', NULL, 'VJF Message from Wayne001 \nQue bola?'),
(87, 2, 32, '2013-12-12 10:25:16', NULL, 'VJF Message from Wayne001 \nhey maine2');

-- --------------------------------------------------------

--
-- Table structure for table `student_skill_map`
--

CREATE TABLE IF NOT EXISTS `student_skill_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `skillid` int(11) DEFAULT NULL,
  `level` varchar(45) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_student_skill_student_idx` (`userid`),
  KEY `FK_student_skill_skill_idx` (`skillid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `student_skill_map`
--

INSERT INTO `student_skill_map` (`id`, `userid`, `skillid`, `level`, `ordering`) VALUES
(5, 23, 33, NULL, 1),
(6, 23, 54, NULL, 2),
(7, 39, 1, NULL, 1),
(8, 39, 25, NULL, 2),
(9, 2, 1, NULL, 1),
(10, 2, 14, NULL, 2),
(11, 2, 8, NULL, 3),
(12, 31, 1, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `FK_usertype` int(11) NOT NULL,
  `email` varchar(45) NOT NULL,
  `registration_date` datetime NOT NULL,
  `activation_string` varchar(45) NOT NULL,
  `activated` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `disable` int(11) DEFAULT NULL,
  `has_viewed_profile` int(11) DEFAULT NULL,
  `linkedinid` varchar(45) DEFAULT NULL,
  `googleid` varchar(45) DEFAULT NULL,
  `fiucsid` varchar(45) DEFAULT NULL,
  `hide_email` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `FK_usertype_idx` (`FK_usertype`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `FK_usertype`, `email`, `registration_date`, `activation_string`, `activated`, `image_url`, `first_name`, `last_name`, `disable`, `has_viewed_profile`, `linkedinid`, `googleid`, `fiucsid`, `hide_email`) VALUES
(1, 'admin', '$2a$08$gYEPqtQ.VCNHkz0GCKTBKubyHUTZyq3ucMQx2bnqpNZ1p6hIEd2Iu', 3, 'adminemail@cis.fiu.edu', '0000-00-00 00:00:00', '12312sdfsd', 1, '', 'Admin', 'Account', 0, 1, NULL, NULL, NULL, 0),
(2, 'hello5', '$2a$08$AnRfDvQVFnxtpkAG2A5On.7tD23LtOOjbh1dR/mQy.io2vXpkSrDe', 1, 'Joh@aol.com', '2013-09-10 23:14:36', 'tq6ai7p2hx', 1, '/JobFair/images/profileimages/hello5avatar.jpg', 'John', 'Doe', NULL, 1, NULL, NULL, NULL, NULL),
(3, 'hello8', '$2a$08$6eMSbgBgAe.0/OaAh66MQOOZqbg4T8iw45wnAgQbtvsftIY813h.G', 2, 'a552184@drdrb.com', '2013-09-11 01:12:57', 'c6u73iqoox', 1, '/JobFair/images/profileimages/hello8avatar.jpg', 'Mark', 'Moe', NULL, NULL, NULL, NULL, NULL, 0),
(4, 'liriz002', '$2a$08$zDglyn0sqVOdeWinHWIOx./g0YcP9ws8A/Qgygr1iIMom0PMOBE.2', 2, 'liriz002@fiu.edu', '2013-09-11 21:52:33', 'c7t129c1hn', NULL, '/JobFair/images/profileimages/avatarsmall.gif', 'Luis', 'Irizarry', NULL, NULL, NULL, NULL, NULL, 1),
(5, 'hello25', '$2a$08$MVtl4xmkrxy2PMIJcI/YsefMD.W0pw2qA5LDir7UFYxVSzOrBqS7K', 3, 'a610372@drdrb.com', '2013-09-11 23:13:22', 'im6cig1jw1', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'adwda', 'adwawadwad', NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'hello89', '$2a$08$MdbJsSv/SWCd.D4eHO66Y.QEjXDNWMUCz5bOccSrqxmNmr7NxfDhq', 2, 'a610467@drdrb.com', '2013-09-11 23:16:45', 'crb8kbonzf', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'adwa', 'wadad', NULL, NULL, NULL, NULL, NULL, 1),
(7, 'hello6', '$2a$08$CnrrSdTGH.7Ntz2yjsbWQesb/G3dI.XXfFJYA2vlg1x2Na5bLPKa6', 1, 'dwada@aol.com', '2013-09-18 18:32:00', 't2gt1rh3m7', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'hello6', 'dw', NULL, 1, NULL, NULL, NULL, NULL),
(8, 'ncapo006', '$2a$08$rT1/LYo5wVUeUFUMp/7qFeSxAdCa64v7hGMrvOUu0QXghF0AeyBmC', 1, 'ncapo006@fiu.edu', '2013-10-19 20:15:05', 'fiucssenior', 1, NULL, 'nelson', 'capote', NULL, 1, NULL, NULL, '1234566', NULL),
(21, 'hello51', '$2a$08$be5c0Iee.uemsByhhcrCfuya3qLEYI1SAjMPn7hPfwjjGSCPvAvC6', 1, 'dwd@aol.com', '2013-11-03 18:40:25', 'jugs2fncuy', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'dawdawd', 'awdawdw', NULL, 1, NULL, NULL, NULL, NULL),
(22, 'lfern203', '$2a$08$VvGYdZZgGVxH2eYl.GwvDOmetiRhHzbzRnYwxwsSkcVGaRXwqCiSS', 1, 'lfern203@fiu.edu', '2013-11-04 14:42:42', 'fiucssenior', 1, NULL, 'linnet', 'fernandez', NULL, NULL, NULL, NULL, '2283690', NULL),
(23, 'jdoe', '$2a$08$ts98pw3vdi4YOBvy4bvP/eTbRRYvfiLvg0Hf6/RHIWs3ryfr31cBW', 2, 'jd@127.0.0.1', '2013-11-25 09:55:57', 'activa', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'John', 'Doe', NULL, 1, NULL, NULL, NULL, NULL),
(24, 'janedoe001', '$2a$08$rsMrRZHgZGiFpwN5R2ii2Or/d3TtYoqfecVj4bgXAV65WvHj/fh6C', 1, 'jad@127.0.0.1', '2013-12-05 23:05:41', '6xmpv1w9dv', 1, '/JobFair/images/profileimages/janedoe001avatar.jpg', 'Jane', 'Doe', NULL, 1, NULL, NULL, NULL, NULL),
(25, 'Johnk', '$2a$08$8vh1Zc8fDiTUuiCIaANdruBwdql/fZPtRlKgIAr./Stz9J3tzHh9y', 2, 'jfernd096@fiu.edu', '2013-12-11 11:21:26', 'lt4l3j1bbq', NULL, '/JobFair/images/profileimages/avatarsmall.gif', 'johnk', 'pull', NULL, NULL, NULL, NULL, NULL, 1),
(26, 'hik25', '$2a$08$e/sC.yM7d.5CvpW.1Yy6EetHU4qIC2wRBIY1ni0JwiD.dA5ZolejO', 2, 'dwdw@aol.com', '2013-12-11 11:24:46', '04nv8rojur', NULL, '/JobFair/images/profileimages/avatarsmall.gif', 'John', 'fan', NULL, NULL, NULL, NULL, NULL, 1),
(27, 'working', '$2a$08$p4r09FR9kybp5FgWT/Sq5e2jD44exyjhBUUmIfPLzuMMBWFYKzXBK', 2, 'adw@aol.com', '2013-12-11 11:40:27', 'th0buqolib', NULL, '/JobFair/images/profileimages/avatarsmall.gif', 'John', 'lak25', NULL, NULL, NULL, NULL, NULL, 1),
(28, 'john', '$2a$08$kuJAoMexqY5DxjhAAFvu0.gJ1zMWV2bZER4/LybE2Bl2GUR5JM6UG', 2, 'dawwd@aol.com', '2013-12-11 11:44:01', 'y9ecxqugdu', NULL, '/JobFair/images/profileimages/avatarsmall.gif', 'lok', 'hahahahaahha', NULL, NULL, NULL, NULL, NULL, 0),
(29, 'john1', '$2a$08$Pv6nzVzByxTZ4rq30sMBE.O.vaIF/8n91fZQm/qKbwXFqi8G8a9hW', 2, 'dawwdd@aol.com', '2013-12-11 11:45:02', 'foutt5wan0', NULL, '/JobFair/images/profileimages/avatarsmall.gif', 'lok1', 'hahahahaahha', NULL, NULL, NULL, NULL, NULL, 1),
(30, 'jokh', '$2a$08$SwZ1c1veibqaMgqUlzb6u.7KWFk7SlPKx/PyjTx.bs5ZWfl34WncC', 1, 'dawdwdD@aol.com', '2013-12-11 11:45:54', '78jjlu64ck', NULL, '/JobFair/images/profileimages/avatarsmall.gif', 'Hey', 'lok', NULL, NULL, NULL, NULL, NULL, NULL),
(31, 'clau001', '$2a$08$gYEPqtQ.VCNHkz0GCKTBKubyHUTZyq3ucMQx2bnqpNZ1p6hIEd2Iu', 1, 'clauida92@yahoo.es', '2013-12-12 00:38:20', '3je10wioue', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'Claudia', 'hernandez', NULL, 1, NULL, NULL, NULL, NULL),
(32, 'Wayne001', '$2a$08$2zbaRQZGdwjtSo69Yean7uToDxAk6hcmtmKwvISDaxS/3K5GyDiyy', 2, 'jfern096@fiu.edu', '2013-12-12 00:43:16', '7yz6ii1nw5', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'John', 'Wayne', NULL, NULL, NULL, NULL, NULL, 0),
(33, 'laib', '$2a$08$jQwXmQOq1vZkEN4pqa0Vxev5R5gnPxc/hD3fc/TpEe6XfWdWcNAkW', 2, 'lairizar@fiu.edu', '2013-12-12 01:38:34', 'a23rh17m2h', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'Luis', 'Irizarry', NULL, NULL, NULL, NULL, NULL, 1),
(35, 'lbenj001', '$2a$08$inQYAfjdua1guqOMbV/va.6AO..Kw.u6Dk7h5i2kBZK.zLn9ZJwwG', 1, 'lbenj001@fiu.edu', '2013-12-12 04:02:41', 'fiucssenior', 1, NULL, 'luis', 'benjumea', NULL, NULL, NULL, NULL, '3501359', NULL),
(36, 'msadjadi', '$2a$08$wCWnX6B/qmgpHkXztXbOOe6Lc/bC5InLgR16BDENCBZS.xxJ3wRme', 1, 'sadjadi@cs.fiu.edu', '2013-12-12 06:59:05', 'ophit81f14', 1, '/JobFair/images/profileimages/msadjadiavatar.jpg', 'Masoud', 'Sadjadi', NULL, 1, NULL, NULL, NULL, NULL),
(37, 'caraballo001', '$2a$08$zMZztrWO5JbMwd5qaDFIQ..RYUIusTmbnRDy3vdLhPmG0lWau3/kK', 2, 'jcaraballo@ibmibm.com', '2013-12-12 10:26:58', 'po47ouknp5', 1, '/JobFair/images/profileimages/caraballo001avatar.jpg', 'Juan', 'Caraballo', NULL, NULL, NULL, NULL, NULL, 0),
(38, 'Johns', '$2a$08$G3ZuyMLcZz0pZnWP7LDkVeLH8T3c/dPHE6FH6GDeC7vFfOfGBrtGe', 2, 'jfern0916@fiu.edu', '2013-12-12 15:49:09', 'z9gy7hh66m', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'John', 'SMith', NULL, NULL, NULL, NULL, NULL, 1),
(39, 'jfern096', '$2a$08$eKO4Jdz3SuQN8iFNTxgBb./eC7LUVz/9m0TI8CoDQA/1YjOP9it9S', 1, 'jfern01196@fiu.edu', '2013-12-12 15:57:26', 'gxjiuxqfax', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'Jorge', 'Fernandez', NULL, 1, NULL, NULL, NULL, NULL),
(40, 'virtualjobfair2013@gmail.com', '$2a$08$Vj0k.FE5inmJ2ECcQf7ti.yd3EyzVsUf43vv56StJjWb5/8idLqGK', 1, 'virtualjobfair2013@gmail.com', '2013-12-12 18:11:33', 'linkedin', 1, NULL, 'srprog-2013', '-fall', NULL, 1, 'Jk1FOEgCaa', NULL, NULL, NULL),
(41, 'juanc', '$2a$08$Bf7m9omhB10yNcykZ83/.ObYAmSPG/SAyi1P2erFhiexHrUtjM1F6', 2, 'jfc@us.ibm.com', '2013-12-12 19:35:05', 'sk9thtd77f', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'juan', 'c', NULL, NULL, NULL, NULL, NULL, 0),
(42, 'juanstudent', '$2a$08$okREVQ8Bw387T5e5UuxLAu4N2BpRdLQkVn2TWctNt8LL.LnOkbs6m', 1, 'caraballojf@gmail.com', '2013-12-12 20:35:59', 'gu97lgc65i', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'j', 'cara', NULL, NULL, NULL, NULL, NULL, NULL),
(43, 'jtb01', '$2a$08$Xvea5y8Kk37nRZkfNgpvFuLMWfQ19.4jXgdC9uldY9IFE8n9Y/0la', 2, 'jtb@127.0.0.1', '2013-12-12 20:47:15', '9sx07az5k2', 1, '/JobFair/images/profileimages/avatarsmall.gif', 'john', 'baker', NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE IF NOT EXISTS `usertype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `usertype`
--

INSERT INTO `usertype` (`id`, `type`) VALUES
(1, 'Student'),
(2, 'Employer'),
(3, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `user_document`
--

CREATE TABLE IF NOT EXISTS `user_document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active_status` tinyint(1) NOT NULL DEFAULT '0',
  `document_id` varchar(256) CHARACTER SET utf8 NOT NULL,
  `local_user_id` int(11) NOT NULL,
  `remote_user_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `document_path` varchar(256) CHARACTER SET utf8 NOT NULL,
  `document_name` varchar(256) CHARACTER SET utf8 NOT NULL,
  `owner_url` varchar(256) CHARACTER SET utf8 NOT NULL,
  `viewer_url` varchar(256) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=119 ;

--
-- Dumping data for table `user_document`
--

INSERT INTO `user_document` (`id`, `active_status`, `document_id`, `local_user_id`, `remote_user_id`, `owner_id`, `document_path`, `document_name`, `owner_url`, `viewer_url`) VALUES
(118, 1, 'kji', 3, 39, 3, '/var/www/html/JobFair/userHomes/hello8/', 'eagle', '', ''),
(117, 1, 'kji', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', 'roach', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd707d4b894f379e45f64fe1a005b254003e10606c88291827c88019ec6e6d4d58&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd707d4b894f379e45f64fe1a005b254003e10606c88291827f435fd1746de9554&top=true\n'),
(116, 1, 'TestNww', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', 'anteater', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde89aa9d32cce78d7f64fe1a005b254003e10606c88291827a5abf9aef93493a2&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde89aa9d32cce78d7f64fe1a005b254003e10606c88291827b62c381d7fe8b114&top=true\n'),
(115, 1, 'TestNother', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', 'hippo', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdcab4be54d4616836f64fe1a005b254003e10606c88291827847f08556217deff&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdcab4be54d4616836f64fe1a005b254003e10606c88291827f6ec30bdd76a4e4b&top=true\n'),
(16, 0, '528e4bf3e8386', 3, 3, 3, '/var/www/html/JobFair/userHomes/hello8/', '528e4bf3e8386.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd94609d3a11f65844f64fe1a005b254007c8fb52d0f731e494100f6776012aab6&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd94609d3a11f65844f64fe1a005b254007c8fb52d0f731e49224318974269bfff&top=true\n'),
(18, 0, '528fc35077652', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '528fc35077652.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4d7140274d14199ef64fe1a005b254007c8fb52d0f731e491b40c3013c9a3367&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4d7140274d14199ef64fe1a005b254007c8fb52d0f731e49de96740bf629da2a&top=true\n'),
(19, 0, '52932c2c1e9bc', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52932c2c1e9bc.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd18da9a62876d228ff64fe1a005b254007c8fb52d0f731e4900e620ca8f5baf75&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd18da9a62876d228ff64fe1a005b254007c8fb52d0f731e496bbcfa14da479fb8&top=true\n'),
(20, 0, '529332a29c566', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529332a29c566.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bda330fad63411ef36f64fe1a005b254007c8fb52d0f731e49ee6b5c3eae9ff9c0&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bda330fad63411ef36f64fe1a005b254007c8fb52d0f731e493e8ea49ff6b96847&top=true\n'),
(21, 0, '5293333d1205e', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '5293333d1205e.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd902fa134675b88eef64fe1a005b254007c8fb52d0f731e49355c0871b0567a44&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd902fa134675b88eef64fe1a005b254007c8fb52d0f731e4948379987aef844a7&top=true\n'),
(66, 0, '52a8d347bdac1', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8d347bdac1.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4c2d958029861e5ef64fe1a005b254003e10606c88291827e5805193ec416efb&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4c2d958029861e5ef64fe1a005b254003e10606c88291827ebfc54a79cf81ca3&top=true\n'),
(23, 0, '5293363d97834', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '5293363d97834.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd1c5b7e6b763c83d9f64fe1a005b254007c8fb52d0f731e49cbeab0dafd58af05&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd1c5b7e6b763c83d9f64fe1a005b254007c8fb52d0f731e491824af40a1c9aebb&top=true\n'),
(24, 0, '5293e4e9550a9', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '5293e4e9550a9.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bddc1d4cbc20fd42a3f64fe1a005b254007c8fb52d0f731e49eb24b528791b8553&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bddc1d4cbc20fd42a3f64fe1a005b254007c8fb52d0f731e494a82e6f129a21ba3&top=true\n'),
(56, 0, '52a8bbbaa28c0', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52a8bbbaa28c0.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd8f700877c0b53924f64fe1a005b254003e10606c882918277f686b44d05cfaf9&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd8f700877c0b53924f64fe1a005b254003e10606c882918271ac7bd0eab918683&top=true\n'),
(26, 0, '529e6042ba025', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529e6042ba025.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd31c518343f27f024f64fe1a005b254003e10606c882918275da4016ceb565efa&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd31c518343f27f024f64fe1a005b254003e10606c88291827f0f1aedc76c25d5b&top=true\n'),
(27, 0, '529e6044b15d1', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529e6044b15d1.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde43d46c73e8e230df64fe1a005b254003e10606c8829182700653a77423ca164&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde43d46c73e8e230df64fe1a005b254003e10606c88291827de9cab9e8b86aa16&top=true\n'),
(28, 0, '529e70302ef6d', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529e70302ef6d.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdb269ec16cab77506f64fe1a005b254003e10606c882918276dade90c1accb22f&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdb269ec16cab77506f64fe1a005b254003e10606c8829182788acd07f000a3336&top=true\n'),
(29, 0, '529e7031eb723', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529e7031eb723.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd7f436157580f4d3af64fe1a005b254003e10606c88291827c4d6e26a3ce1bc01&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd7f436157580f4d3af64fe1a005b254003e10606c8829182792302b8569326a4a&top=true\n'),
(63, 0, '52a8c88600713', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8c88600713.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd9b05471462eb3261f64fe1a005b254003e10606c88291827074de79040fe298e&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd9b05471462eb3261f64fe1a005b254003e10606c882918270b095ec5afc5b1ec&top=true\n'),
(32, 0, '529e85168053d', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529e85168053d.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4e6d16d0059fa8d9f64fe1a005b254003e10606c8829182728740dfa131622ae&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4e6d16d0059fa8d9f64fe1a005b254003e10606c882918278661f153687a0d1c&top=true\n'),
(33, 0, '529e8c5f159f4', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '529e8c5f159f4.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdcf9f9c48261f4e68f64fe1a005b254003e10606c88291827deb561cd8eaaf49f&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdcf9f9c48261f4e68f64fe1a005b254003e10606c88291827cd915790d829ecb6&top=true\n'),
(34, 0, '529e8c8a9f22d', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '529e8c8a9f22d.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdb3d00ad1820e4942f64fe1a005b254003e10606c882918273b5f6a81e6df8713&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdb3d00ad1820e4942f64fe1a005b254003e10606c882918270cce36317f118629&top=true\n'),
(35, 0, '529e8c9f1b785', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '529e8c9f1b785.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd5feea16cf44df4bcf64fe1a005b254003e10606c8829182708966916a48eed72&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd5feea16cf44df4bcf64fe1a005b254003e10606c88291827d75e70d4b365ec25&top=true\n'),
(36, 0, '529e99131b167', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529e99131b167.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde39ba4dc20e30348f64fe1a005b254003e10606c8829182792f1104c1d70a3e6&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde39ba4dc20e30348f64fe1a005b254003e10606c88291827178689cd5ac0a02d&top=true\n'),
(37, 0, '529ea35f70924', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '529ea35f70924.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd8bb06188cff28e9df64fe1a005b254003e10606c8829182743fdb9fa27d33064&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd8bb06188cff28e9df64fe1a005b254003e10606c88291827956ed8eb34727264&top=true\n'),
(38, 0, '529ea3611b5c2', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '529ea3611b5c2.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd3346ae46b0abc58ff64fe1a005b254003e10606c88291827dae1cd495866ed02&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd3346ae46b0abc58ff64fe1a005b254003e10606c882918276f264b101768a749&top=true\n'),
(39, 0, '529ecd690f68a', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '529ecd690f68a.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd0d96f746bace6e5cf64fe1a005b254003e10606c882918271addbd120c17bb48&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd0d96f746bace6e5cf64fe1a005b254003e10606c88291827f7ae63820ba8421e&top=true\n'),
(40, 0, '529f3ed869f04', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '529f3ed869f04.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd2d33256259737e0cf64fe1a005b254003e10606c882918279919d56b5a9e332d&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd2d33256259737e0cf64fe1a005b254003e10606c882918274dbeb475c10d9d16&top=true\n'),
(41, 0, '529f8d8d7d0ae', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529f8d8d7d0ae.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdd03cd9b01f49b79cf64fe1a005b254003e10606c88291827a183add70b84d841&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdd03cd9b01f49b79cf64fe1a005b254003e10606c882918273d9f4fb8b6736bb0&top=true\n'),
(42, 0, '529f8d9522bf0', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529f8d9522bf0.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bda02e19c954bad9b1f64fe1a005b254003e10606c88291827b451584fe917a8eb&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bda02e19c954bad9b1f64fe1a005b254003e10606c88291827d6288a18db1bb2dc&top=true\n'),
(43, 0, '529f97ae978b4', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '529f97ae978b4.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd81721cc816ccba6ff64fe1a005b254003e10606c8829182776c395bcde1f3e7b&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd81721cc816ccba6ff64fe1a005b254003e10606c882918275cb094dbff382eeb&top=true\n'),
(44, 0, '52a0c6a5e284b', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52a0c6a5e284b.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdb2f9c5127cca4b8ff64fe1a005b254003e10606c88291827e268a02285a00bb7&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdb2f9c5127cca4b8ff64fe1a005b254003e10606c882918275707cc2b7cba9ee9&top=true\n'),
(45, 0, '52a10b8fa2e88', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52a10b8fa2e88.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdbfe0baf8577fb68ff64fe1a005b254003e10606c882918271e379833472ed9e7&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdbfe0baf8577fb68ff64fe1a005b254003e10606c8829182715f3b3c3e7f46c6c&top=true\n'),
(46, 0, '52a12e1e2c6c6', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52a12e1e2c6c6.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdc0ef903c1462126ff64fe1a005b254003e10606c88291827d61c85958d2c8195&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdc0ef903c1462126ff64fe1a005b254003e10606c882918270d30ec4b89a3a9f5&top=true\n'),
(47, 0, '52a14e6d2b5b7', 24, 23, 24, '/var/www/html/JobFair/userHomes/janedoe001/', '52a14e6d2b5b7.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde2aa24906e9a12e8f64fe1a005b254003e10606c882918273383ff60887f9ce9&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde2aa24906e9a12e8f64fe1a005b254003e10606c882918276bcdfd301495c9ce&top=true\n'),
(48, 1, '52a14ea01d24e', 24, 23, 24, '/var/www/html/JobFair/userHomes/janedoe001/', '52a14ea01d24e.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd519d0d37103339b7f64fe1a005b254003e10606c88291827f876741087f4c909&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd519d0d37103339b7f64fe1a005b254003e10606c88291827a6717aeeb6bc0325&top=true\n'),
(65, 0, '52a8d13b9e201', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8d13b9e201.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdb79ba58267e9ddeef64fe1a005b254003e10606c882918274b2199d530053eab&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdb79ba58267e9ddeef64fe1a005b254003e10606c88291827e6a0e6d1b7faebfa&top=true\n'),
(50, 0, '52a6959cb43b2', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52a6959cb43b2.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd406557459adca4f8f64fe1a005b254003e10606c882918274a1773c0a7b411bd&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd406557459adca4f8f64fe1a005b254003e10606c882918277151b07515aa90d5&top=true\n'),
(51, 0, '52a6959ea4356', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52a6959ea4356.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd28815a7a6eba4fa9f64fe1a005b254003e10606c8829182706c8821a6a08529c&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd28815a7a6eba4fa9f64fe1a005b254003e10606c882918270597c7d45ab96c37&top=true\n'),
(55, 0, '52a8bba259d31', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52a8bba259d31.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd15f73a443995ba8af64fe1a005b254003e10606c88291827f7490d2e18e4525f&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd15f73a443995ba8af64fe1a005b254003e10606c882918276877e05ee6f446b1&top=true\n'),
(67, 0, '52a8d82fb98a7', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8d82fb98a7.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd1a895584a400251bf64fe1a005b254003e10606c882918270bf504625ea7047f&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd1a895584a400251bf64fe1a005b254003e10606c882918275024cd2feb3b31f4&top=true\n'),
(68, 0, '52a8d9237869e', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8d9237869e.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd8fab62296d3d9bb7f64fe1a005b254003e10606c882918275e60dd1e7e124150&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd8fab62296d3d9bb7f64fe1a005b254003e10606c882918277a9bb78498e10eb6&top=true\n'),
(69, 0, '52a8d92faabfa', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8d92faabfa.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde2c869a7f989d4bcf64fe1a005b254003e10606c88291827083dedc406c5421b&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bde2c869a7f989d4bcf64fe1a005b254003e10606c88291827a7abc032cdd27f9c&top=true\n'),
(70, 0, '52a8d93570bbe', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8d93570bbe.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdccb2efc996898dbcf64fe1a005b254003e10606c882918273d71ce49ddad1f84&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdccb2efc996898dbcf64fe1a005b254003e10606c882918271ef20104196eb46e&top=true\n'),
(71, 0, '52a8d9aef070c', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8d9aef070c.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd01f491d2099c3d09f64fe1a005b254003e10606c88291827538f02253ed07fab&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd01f491d2099c3d09f64fe1a005b254003e10606c88291827c77a8e27da94be62&top=true\n'),
(72, 0, '52a8da3102937', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8da3102937.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd377cafb1bc689854f64fe1a005b254003e10606c882918271c1fa3edc5115ed2&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd377cafb1bc689854f64fe1a005b254003e10606c88291827997be28d5be891cd&top=true\n'),
(73, 0, '52a8da3d1689b', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8da3d1689b.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4a57fefd08e7cfbdf64fe1a005b254003e10606c88291827c6bd589e2e5e0b7a&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4a57fefd08e7cfbdf64fe1a005b254003e10606c8829182707273d5450fc5b9b&top=true\n'),
(74, 0, '52a8da823d833', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52a8da823d833.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd3017f960621230eaf64fe1a005b254003e10606c8829182732d72a4f2a0a3533&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd3017f960621230eaf64fe1a005b254003e10606c882918276ae6ef08adb9e08c&top=true\n'),
(75, 0, '52a8dafaf304d', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8dafaf304d.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bddf178bf1b9314611f64fe1a005b254003e10606c8829182735c79e6f8a4059dc&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bddf178bf1b9314611f64fe1a005b254003e10606c88291827b1c442bff156249e&top=true\n'),
(76, 0, '52a8db06e48ac', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8db06e48ac.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd5440ea766c9d9ef0f64fe1a005b254003e10606c88291827b1eed7995eba257c&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd5440ea766c9d9ef0f64fe1a005b254003e10606c8829182729823ad14ec0b0aa&top=true\n'),
(77, 0, '52a8dcd7d13e1', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8dcd7d13e1.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdacbf7d4091be169af64fe1a005b254003e10606c88291827cd1ccc8599ee8450&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdacbf7d4091be169af64fe1a005b254003e10606c88291827d57039785e5dd471&top=true\n'),
(78, 0, '52a8dd3a4f991', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8dd3a4f991.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd767f349640f0a17df64fe1a005b254003e10606c88291827bc75045c7a73fbbe&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd767f349640f0a17df64fe1a005b254003e10606c882918273157b8b76519ba2e&top=true\n'),
(79, 0, '52a8de8178074', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8de8178074.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd3fb473b938752061f64fe1a005b254003e10606c882918279c3d0a3f7283c359&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd3fb473b938752061f64fe1a005b254003e10606c88291827f6b5b4da5fc9731f&top=true\n'),
(80, 0, '52a8df7ae4308', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8df7ae4308.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdddc8abb9c40ed4f9f64fe1a005b254003e10606c88291827511938fc1ff5c1ec&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdddc8abb9c40ed4f9f64fe1a005b254003e10606c88291827e811957a620f4d0f&top=true\n'),
(81, 0, '52a8df89ae300', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8df89ae300.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdf5f503c4c4a582e5f64fe1a005b254003e10606c88291827263b4920458ad347&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdf5f503c4c4a582e5f64fe1a005b254003e10606c8829182794cb3bb4f5b7dfa0&top=true\n'),
(82, 0, '52a8dfa8914ff', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8dfa8914ff.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd025a2a5dc8ef6e16f64fe1a005b254003e10606c882918277e7cc53f1a0864a8&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd025a2a5dc8ef6e16f64fe1a005b254003e10606c88291827f5c60bd51b0d5857&top=true\n'),
(83, 0, '52a8dfb0209b0', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8dfb0209b0.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdda05d98de1ebfd66f64fe1a005b254003e10606c882918273e4421bf9b4a1d14&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdda05d98de1ebfd66f64fe1a005b254003e10606c88291827d020788b8955ab52&top=true\n'),
(84, 0, '52a8ea85afaa7', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a8ea85afaa7.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd208ad59b5cece2aaf64fe1a005b254003e10606c8829182715242de8442841e7&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd208ad59b5cece2aaf64fe1a005b254003e10606c88291827481fd5056f864235&top=true\n'),
(85, 1, '52a94b1035bc7', 3, 2, 3, '/var/www/html/JobFair/userHomes/hello8/', '52a94b1035bc7.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdc2a80bcbc4f2d014f64fe1a005b254003e10606c88291827bb9248646e7c153d&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdc2a80bcbc4f2d014f64fe1a005b254003e10606c88291827ce7211ee47ff8e1c&top=true\n'),
(86, 0, '52a981e74e0be', 2, 33, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a981e74e0be.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4e053abda8ea8204f64fe1a005b254003e10606c88291827d5712ae5a7214ae9&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd4e053abda8ea8204f64fe1a005b254003e10606c882918279b3c3552342f3c69&top=true\n'),
(87, 0, '52a982ac252dc', 2, 33, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a982ac252dc.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdcf5a15c2b3167ca8f64fe1a005b254003e10606c88291827d1a822fb5bc0b3c2&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdcf5a15c2b3167ca8f64fe1a005b254003e10606c88291827e93819f63fcd3cd9&top=true\n'),
(92, 0, '52a9d42cb9451', 32, 32, 32, '/var/www/html/JobFair/userHomes/Wayne001/', '52a9d42cb9451.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdcff50fe99c8f4ba0f64fe1a005b254003e10606c88291827f54d6a7e1ed4f189&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdcff50fe99c8f4ba0f64fe1a005b254003e10606c882918271a94eaaf0db704a6&top=true\n'),
(89, 0, '52a9850479a85', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a9850479a85.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd28ba010c1640442ef64fe1a005b254003e10606c8829182739d4d06c266a9c00&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd28ba010c1640442ef64fe1a005b254003e10606c882918274bc6996cdf9bb72c&top=true\n'),
(90, 0, '52a9858e1f7ff', 2, 3, 2, '/var/www/html/JobFair/userHomes/hello5/', '52a9858e1f7ff.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdfcf4b418825c4bcff64fe1a005b254003e10606c88291827880963ce341d7635&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdfcf4b418825c4bcff64fe1a005b254003e10606c882918271be1294059e9ce4e&top=true\n'),
(93, 0, '52a9d4437ab37', 32, 31, 32, '/var/www/html/JobFair/userHomes/Wayne001/', '52a9d4437ab37.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd9a23295ba4af3cadf64fe1a005b254003e10606c88291827b00f74dc9590847f&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd9a23295ba4af3cadf64fe1a005b254003e10606c882918279fd6484ed733853b&top=true\n'),
(94, 0, '52a9d499ce84e', 32, 32, 32, '/var/www/html/JobFair/userHomes/Wayne001/', '52a9d499ce84e.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdf355a07f43350daaf64fe1a005b254003e10606c882918276676f9de91de300c&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdf355a07f43350daaf64fe1a005b254003e10606c88291827f734276ee83ef61f&top=true\n'),
(95, 1, '52a9d4a4bf666', 32, 31, 32, '/var/www/html/JobFair/userHomes/Wayne001/', '52a9d4a4bf666.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdc4cae65c00486727f64fe1a005b254003e10606c88291827bf2e983a1887e1b7&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bdc4cae65c00486727f64fe1a005b254003e10606c88291827fab52796464f6932&top=true\n'),
(99, 0, '52aa03a921607', 2, 33, 2, '/var/www/html/JobFair/userHomes/hello5/', '52aa03a921607.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd8d8ac903a0862e83f64fe1a005b254003e10606c88291827f0d31c53398ed2d6&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd8d8ac903a0862e83f64fe1a005b254003e10606c882918275e6768b21c6b50b4&top=true\n'),
(100, 0, '52aa044fad7b8', 2, 33, 2, '/var/www/html/JobFair/userHomes/hello5/', '52aa044fad7b8.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd34f70a4f157aee83f64fe1a005b254003e10606c88291827a0d8f2586ad85b32&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd34f70a4f157aee83f64fe1a005b254003e10606c88291827b7aa26403c650542&top=true\n'),
(101, 0, '52aa0475ed6f3', 2, 33, 2, '/var/www/html/JobFair/userHomes/hello5/', '52aa0475ed6f3.doc', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd12e40dbd9f14b264f64fe1a005b254003e10606c882918277403caa923fe413c&top=true\n', 'https://exportwriter.zoho.com/writer/editor.im?doc=e2e696359ed3e3bd12e40dbd9f14b264f64fe1a005b254003e10606c882918279a3b509734553fc3&top=true\n');

-- --------------------------------------------------------

--
-- Table structure for table `video_interview`
--

CREATE TABLE IF NOT EXISTS `video_interview` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FK_employer` int(11) NOT NULL,
  `FK_student` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `session_key` varchar(45) NOT NULL,
  `notification_id` varchar(45) NOT NULL,
  `ScreenShareView` varchar(90) NOT NULL,
  `sharingscreen` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_employer_idx` (`FK_employer`),
  KEY `FK_student_idx` (`FK_student`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `video_interview`
--

INSERT INTO `video_interview` (`id`, `FK_employer`, `FK_student`, `date`, `time`, `session_key`, `notification_id`, `ScreenShareView`, `sharingscreen`) VALUES
(8, 3, 2, '2013-10-31', '01:00:00', '8VJFID6675162', '42', 'http://api.screenleap.com/v2/viewer/056798479?accountid=jfern096', 0),
(7, 3, 2, '2013-11-19', '21:00:00', '7VJFID5212500', '35', 'http://api.screenleap.com/v2/viewer/408422191?accountid=jfern096', 0),
(6, 3, 2, '2013-11-19', '21:01:00', '6VJFID9275510', '28', '', 0),
(5, 3, 2, '2013-09-12', '22:43:00', '1VJFID8984636', '15', '', 0),
(9, 23, 24, '2014-01-31', '13:00:00', '9VJFID586287', '59', '', 0),
(11, 33, 2, '2013-12-14', '01:42:00', '11VJFID1824953', '140', 'http://api.screenleap.com/v2/viewer/541518810?accountid=jfern096', 1),
(12, 33, 23, '2013-12-14', '16:02:00', '12VJFID3127081', '142', '', 0),
(10, 32, 31, '2013-12-13', '14:00:00', '10VJFID1391763', '127', 'http://api.screenleap.com/v2/viewer/824498955?accountid=jfern096', 0),
(13, 37, 36, '2013-12-13', '01:00:00', '13VJFID5666442', '168', 'http://api.screenleap.com/v2/viewer/223744467?accountid=jfern096', 0),
(14, 3, 2, '2013-12-13', '01:00:00', '14VJFID8489549', '194', '', 0),
(15, 3, 39, '2013-12-13', '01:00:00', '15VJFID2474745', '209', 'http://api.screenleap.com/v2/viewer/713894297?accountid=jfern096', 0),
(16, 32, 2, '2013-12-14', '01:00:00', '16VJFID464594', '449', 'http://api.screenleap.com/v2/viewer/561601443?accountid=jfern096', 0);

-- --------------------------------------------------------

--
-- Table structure for table `video_resume`
--

CREATE TABLE IF NOT EXISTS `video_resume` (
  `id` int(11) NOT NULL,
  `video_path` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `video_path_UNIQUE` (`video_path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `whiteboard_sessions`
--

CREATE TABLE IF NOT EXISTS `whiteboard_sessions` (
  `user1` varchar(15) DEFAULT NULL,
  `user2` varchar(15) DEFAULT NULL,
  `interview_id` varchar(20) DEFAULT NULL,
  `image_name` varchar(50) DEFAULT 'none',
  `tmpstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Dumping data for table `whiteboard_sessions`
--

INSERT INTO `whiteboard_sessions` (`user1`, `user2`, `interview_id`, `image_name`, `tmpstamp`) VALUES
('laib', 'hello5', '11VJFID1824953', '11VJFID1824953.jpg', '2013-12-12 06:41:42'),
('hello8', 'hello5', '8VJFID6675162', '8VJFID6675162.png', '2013-12-12 06:35:47'),
('laib', 'jdoe', '12VJFID3127081', '12VJFID3127081.png', '2013-12-12 06:42:47'),
('clau001', 'Wayne001', '10VJFID1391763', 'none', '2013-12-12 15:21:55'),
('msadjadi', 'caraballo001', '13VJFID5666442', 'none', '2013-12-12 15:57:14'),
('hello5', 'hello8', '14VJFID8489549', 'none', '2013-12-13 00:16:12');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `FK_applcation_userid` FOREIGN KEY (`userid`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_application_jobid` FOREIGN KEY (`jobid`) REFERENCES `job` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `basic_info`
--
ALTER TABLE `basic_info`
  ADD CONSTRAINT `basic_info_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `company_info`
--
ALTER TABLE `company_info`
  ADD CONSTRAINT `FK_company_userid` FOREIGN KEY (`FK_userid`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `education`
--
ALTER TABLE `education`
  ADD CONSTRAINT `FK_school_id` FOREIGN KEY (`FK_school_id`) REFERENCES `school` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_student_id` FOREIGN KEY (`FK_user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `experience`
--
ALTER TABLE `experience`
  ADD CONSTRAINT `FK_experience_user` FOREIGN KEY (`FK_userid`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `handshake`
--
ALTER TABLE `handshake`
  ADD CONSTRAINT `FK_handshake_employer` FOREIGN KEY (`employerid`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_handshake_job` FOREIGN KEY (`jobid`) REFERENCES `job` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_handshake_student` FOREIGN KEY (`studentid`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `job`
--
ALTER TABLE `job`
  ADD CONSTRAINT `FK_job_poster` FOREIGN KEY (`FK_poster`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `job_skill_map`
--
ALTER TABLE `job_skill_map`
  ADD CONSTRAINT `FK_job_skill_jobid` FOREIGN KEY (`jobid`) REFERENCES `job` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_job_skill_skillid` FOREIGN KEY (`skillid`) REFERENCES `skillset` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `FK_receiver` FOREIGN KEY (`FK_receiver`) REFERENCES `user` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_sender` FOREIGN KEY (`FK_sender`) REFERENCES `user` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `SMS`
--
ALTER TABLE `SMS`
  ADD CONSTRAINT `receiver_id` FOREIGN KEY (`receiver_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `sender_id` FOREIGN KEY (`sender_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `student_skill_map`
--
ALTER TABLE `student_skill_map`
  ADD CONSTRAINT `FK_student_skill_skill` FOREIGN KEY (`skillid`) REFERENCES `skillset` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_student_skill_student` FOREIGN KEY (`userid`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `FK_usertype` FOREIGN KEY (`FK_usertype`) REFERENCES `usertype` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
