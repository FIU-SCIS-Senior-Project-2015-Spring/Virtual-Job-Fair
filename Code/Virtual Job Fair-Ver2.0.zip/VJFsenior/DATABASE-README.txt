Two Database .sql scripts are provided to re-create the database
1. jobfairdb.sql
2. jobfairdb-with-sample-data.sql

---------------------------------

+ jobfairdb.sql:

Contains a cleaned up version of the database with the minimal amount of data needed to get the project running, this version was cleaned and successfully recreates and repopulates the database. In case this doesn't work for you, fallback to the second file which contains a sql dump of the database guaranteed to work 100% ( with the caveat that it contains some data/entries already )

+ jobfairdb-with-sample-data.sql:

Contains a dump of the database from the live/working project, it's guaranteed to work 100% with the caveat that it contains some data/entries already, although this may be useful in the sense that it may give you an insight of how data across the project relates to each other and how the project works.